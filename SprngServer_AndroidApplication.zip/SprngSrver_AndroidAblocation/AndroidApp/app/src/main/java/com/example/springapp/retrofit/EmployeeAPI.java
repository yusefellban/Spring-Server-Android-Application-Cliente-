package com.example.springapp.retrofit;

import com.example.springapp.model.Employee;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface EmployeeAPI {
    @GET("/employee/get-All")
    Call<List<Employee>> getAllEmployees();


    @POST("/employee/save")
    Call<Employee> save(@Body Employee employee);

}
