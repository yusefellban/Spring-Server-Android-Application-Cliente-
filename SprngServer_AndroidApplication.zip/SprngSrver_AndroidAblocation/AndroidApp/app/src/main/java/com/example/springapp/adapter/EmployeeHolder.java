package com.example.springapp.adapter;


import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.springapp.R;

public class EmployeeHolder extends RecyclerView.ViewHolder {

    TextView name, location, Company;

    public EmployeeHolder(@NonNull View itemView) {
        super(itemView);
        name = itemView.findViewById(R.id.employeeListItem_name);
        location = itemView.findViewById(R.id.employeeListItem_location);
    }
}
