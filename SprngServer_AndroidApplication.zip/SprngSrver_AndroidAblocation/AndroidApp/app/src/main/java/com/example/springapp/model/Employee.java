package com.example.springapp.model;
/*
this annotation to make my code to accesses DB to create it
 */

public class Employee {
  //to auto increment for the id
    private int id; //it will be a primary key and auto increment
    private String name;
    private String location;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", location='" + location + '\''+
                '}';
    }
}
