package com.yousef.SpringServer;

import com.yousef.SpringServer.model.employee.Employee;
import com.yousef.SpringServer.model.employee.EmployeeDatabaseFunctions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class SpringServerApplicationTests {
@Autowired
   private 	EmployeeDatabaseFunctions employeeDatabaseFunctions;
	@Test
	void AddEmployeeTest() {
    Employee employee=new Employee();
	employee.setName("Yousef");
	employee.setLocation("Alexandrea");
	employee.setCompany("googel");
	 employeeDatabaseFunctions.save(employee);
	}

    @Test
	 void getAllEmployees(){
	List<Employee> ee= employeeDatabaseFunctions.FindAll();
	System.out.println(ee);
}


}
