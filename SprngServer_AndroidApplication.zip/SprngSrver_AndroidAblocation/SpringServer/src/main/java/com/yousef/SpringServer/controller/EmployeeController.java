package com.yousef.SpringServer.controller;

import com.yousef.SpringServer.model.employee.Employee;
import com.yousef.SpringServer.model.employee.EmployeeDatabaseFunctions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

@RestController
public class EmployeeController {
    @Autowired
    private EmployeeDatabaseFunctions employeeDatabaseFunctions;

    /**
     * in mobile application we use this url to get all the data
     * @return
     */
    @GetMapping("/employee/get-All")
    public List<Employee> GetAllEmployeeToAndroid(){
        return employeeDatabaseFunctions.FindAll();
    }

    /**
     * in mobile application we use the folwing url to send data to the serer (Spring)
     */

    @PostMapping("/employee/save")
    public Employee save(@RequestBody Employee employee){
        return employeeDatabaseFunctions.save(employee);
    }

}


