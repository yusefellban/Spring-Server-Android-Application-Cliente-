package com.yousef.SpringServer.model.employee;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Streamable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class EmployeeDatabaseFunctions  {
    /**
     * to get an object from the EmployeeRepository interface and accesses the data
     * Spring do a dependence injection
     */
    @Autowired
    private EmployeeRepository  repository;

    public Employee save(Employee employee){
        return repository.save(employee);
    }

    /**
     * There is anouthr two ways
     * 1-return list
     * 2-using Guava
     * but this way get the data step step iterable
     */
    public List<Employee> FindAll(){
        List<Employee> employee =new ArrayList<>();
        Streamable.of(repository.findAll()).forEach(employee::add);
        return employee;

    }
    public void delete(Employee employee){
        repository.delete(employee);
    }


}
